"use strict";

// This is going to be used in /assets/js/app.js
var CONFIG = {};

// CONFIG = {

//     // Various toast messages
//     toastMessages: {
//         nameMissing: 'Looks like you forgot to introduce yourself.',
//         contactMissing: 'Let us know how to contact you.',
//         messageMissing: 'You forgot to include a message to us :-)',
//         enterValidEmail: 'Please enter a valid email address.',
//         messageSent: 'Your message has been sent. We\'ll get back to you soon.',
//         somethingWrong: 'Something went wrong, try again. Error: '
//     },

//     // Default Toast dismissal time
//     toastSpeed: 4000
// };
