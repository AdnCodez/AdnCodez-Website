function removeInline() {
    document.onload = document.querySelector('#contact').style = '';
}
setTimeout(removeInline, 1);
